<form action="" method="post">
<h1 >ADD STORE</h1>
    <div class="form-group">
        <label>Nom :</label>
        <input name="name" type="text" class="form-control">
    </div><br>
    <div class="form-group">
        <label>Adresse :</label>
        <input name="email" type="text" class="form-control">
    </div><br>
    <div class="form-group">
        <label>Email :</label>
        <input name="annee" type="text" class="form-control">
    </div><br>
    <div class="form-group">
        <label>Telephone :</label>
        <input name="telephone" type="text" class="form-control">
    </div><br>
    <input type="submit" name="submit" value="save" class="btn btn-primary">
</form>