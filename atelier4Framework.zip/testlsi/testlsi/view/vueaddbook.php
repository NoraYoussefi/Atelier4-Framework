
<h1><?php echo $toto  ?></h1>

<form  method="post" >
   
        <label>name :</label>
        <input  name="name" type="text" class="form-control">
    <br>
    
        <label>Auteur :</label>
        <input   name="auteur" type="text" class="form-control">
   ><br>
    
        <label>Annee :</label>
        <input  name="annee" type="text" class="form-control">
    <br>

    <input type="submit" value="save" class="btn btn-primary">
</form>