<?php
require_once "controller/Router.php";

$routeur = new Routeur();
$routeur->routerRequete();


?>